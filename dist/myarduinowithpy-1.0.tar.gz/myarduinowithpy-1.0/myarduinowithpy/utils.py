# utils.py
def list_serial_ports():
    """List all available serial ports."""
    return ["COM1", "COM2", "/dev/ttyUSB0"]  # Placeholder for actual port scanning
