# __init__.py
"""Initialization file for the myarduinowithpy package."""
from .core import Arduino